using BookManagementMVC.Data;
using BookManagementMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookManagementMVC.Controllers;

public class BooksController : Controller
{
    private const string ImageUrlFolder = "/images/books/";
    private const long MaxImageSize = 2 * 1024 * 1024; // 2MB
    private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".webp" };

    private readonly ApplicationDbContext _context;
    private readonly IWebHostEnvironment _env;

    public BooksController(ApplicationDbContext context, IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    public async Task<IActionResult> Index(string? searchString)
    {
        var books = _context.Books.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(searchString))
        {
            books = books.Where(b => b.Title.Contains(searchString) || b.Author.Contains(searchString));
        }

        ViewData["SearchString"] = searchString;
        return View(await books.OrderByDescending(b => b.Id).ToListAsync());
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();

        var book = await _context.Books.AsNoTracking().FirstOrDefaultAsync(b => b.Id == id);
        if (book == null) return NotFound();

        return View(book);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Book book, IFormFile? imageFile)
    {
        book.ImagePath = null;

        if (imageFile is { Length: > 0 })
        {
            var error = ValidateImage(imageFile);
            if (error != null) ModelState.AddModelError("imageFile", error);
        }

        if (!ModelState.IsValid) return View(book);

        if (imageFile is { Length: > 0 })
        {
            book.ImagePath = await SaveImageAsync(imageFile);
        }

        _context.Books.Add(book);
        await _context.SaveChangesAsync();
        TempData["Success"] = "Thêm sách thành công.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();

        var book = await _context.Books.FindAsync(id);
        if (book == null) return NotFound();

        return View(book);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Book book, IFormFile? imageFile)
    {
        if (id != book.Id) return NotFound();

        var existing = await _context.Books.FindAsync(id);
        if (existing == null) return NotFound();

        if (imageFile is { Length: > 0 })
        {
            var error = ValidateImage(imageFile);
            if (error != null) ModelState.AddModelError("imageFile", error);
        }

        if (!ModelState.IsValid)
        {
            book.ImagePath = existing.ImagePath; // giữ ảnh cũ để hiển thị lại form
            return View(book);
        }

        existing.Title = book.Title;
        existing.Author = book.Author;
        existing.Category = book.Category;
        existing.Price = book.Price;
        existing.PublishedYear = book.PublishedYear;

        if (imageFile is { Length: > 0 })
        {
            DeleteImage(existing.ImagePath);
            existing.ImagePath = await SaveImageAsync(imageFile);
        }

        await _context.SaveChangesAsync();
        TempData["Success"] = "Cập nhật sách thành công.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();

        var book = await _context.Books.AsNoTracking().FirstOrDefaultAsync(b => b.Id == id);
        if (book == null) return NotFound();

        return View(book);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var book = await _context.Books.FindAsync(id);
        if (book != null)
        {
            DeleteImage(book.ImagePath);
            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
            TempData["Success"] = "Xóa sách thành công.";
        }

        return RedirectToAction(nameof(Index));
    }

    // ----- Helpers upload ảnh -----

    private static string? ValidateImage(IFormFile file)
    {
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!AllowedExtensions.Contains(ext))
            return "Chỉ chấp nhận ảnh .jpg, .jpeg, .png, .gif, .webp";
        if (!file.ContentType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
            return "File tải lên không phải là hình ảnh";
        if (file.Length > MaxImageSize)
            return "Ảnh không được vượt quá 2MB";
        return null;
    }

    private string ImageFolderPath => Path.Combine(_env.WebRootPath, "images", "books");

    private async Task<string> SaveImageAsync(IFormFile file)
    {
        Directory.CreateDirectory(ImageFolderPath);
        var fileName = $"{Guid.NewGuid():N}{Path.GetExtension(file.FileName).ToLowerInvariant()}";
        await using var stream = new FileStream(Path.Combine(ImageFolderPath, fileName), FileMode.Create);
        await file.CopyToAsync(stream);
        return ImageUrlFolder + fileName;
    }

    private void DeleteImage(string? imagePath)
    {
        if (string.IsNullOrEmpty(imagePath) || !imagePath.StartsWith(ImageUrlFolder)) return;
        var fullPath = Path.Combine(ImageFolderPath, Path.GetFileName(imagePath));
        if (System.IO.File.Exists(fullPath)) System.IO.File.Delete(fullPath);
    }
}
