using System.Diagnostics;
using System.Text.RegularExpressions;

namespace BookManagementMVC.Middlewares;

public class RequestLoggingMiddleware
{
    // Khớp /Books/Details/{id} (URL thật của project) và cả /Book/Detail/{id} (theo đề),
    // cho phép id âm và dấu "/" ở cuối.
    private static readonly Regex DetailPath = new(
        @"^/Books?/Details?/(?<id>-?\d+)/?$",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private readonly RequestDelegate _next;

    public RequestLoggingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var stopwatch = Stopwatch.StartNew();
        var method = context.Request.Method;
        var path = context.Request.Path.ToString();

        // Chức năng 1: log request (có mili giây)
        Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] Method: {method} - Path: {path}");

        // Chức năng 3: chặn id <= 0
        var match = DetailPath.Match(path);
        if (match.Success && long.TryParse(match.Groups["id"].Value, out var id) && id <= 0)
        {
            context.Response.StatusCode = StatusCodes.Status400BadRequest;
            context.Response.ContentType = "text/plain; charset=utf-8";
            await context.Response.WriteAsync("Book id không hợp lệ");

            Console.WriteLine($"Status Code: {context.Response.StatusCode} - {stopwatch.Elapsed.TotalMilliseconds:F2} ms");
            return; // không gọi _next => request không vào Controller
        }

        await _next(context);

        // Chức năng 2: log status code sau khi xử lý xong
        Console.WriteLine($"Status Code: {context.Response.StatusCode} - {stopwatch.Elapsed.TotalMilliseconds:F2} ms");
    }
}
